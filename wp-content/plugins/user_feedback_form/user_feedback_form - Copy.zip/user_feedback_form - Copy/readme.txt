=== User Feed Back Form===
Contributors: ODC Huy Eng)
Donate link:
Tags: feedback, submit issue, contact form, open data
Requires at least: 4.0.0
Tested up to: 4.0
Stable tag: trunk
License: GPLv3 / copyright (c) 2014-2015 East-West Management Institute, Inc. (EWMI).
License URI: http://www.gnu.org/licenses/gpl-3.0.html

user_feedback_form is a wordpress plugin that exposes a series of functionalities to gather contact, feedback, identify, and submit the reports form the users in  easiest way. 

This plugin was forked form the previous plugin named "userfeedback"developed by Mr. Heng Cham Roeun by improving some functionalities to support the Multiple Wordpress site and creating the shortcode for displaying in some content of the pages. 

== Description ==
