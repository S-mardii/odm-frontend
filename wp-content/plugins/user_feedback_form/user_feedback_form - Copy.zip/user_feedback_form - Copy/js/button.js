jQuery(document).ready(function($) {
	//$("a#user_feedback_form").after('<div id="overlay-div"></div>'); 
    $("a#user_feedback_form").click(function(e) {
	       //	var hostname = window.location.host + (window.location.host.indexOf("192")>=0?"/ODC":"");
		//var lang = window.location.pathname.indexOf("/kh/")>=0?"kh":"en";
		                        
         $("div#wrap-feedback").after('<div id="overlay-div"></div>');
		 $("div#overlay-div").after('<div id="loading"></div>'); 
		 $("div#overlay-div").after('<div id="div_user_feedback_form"></div>');  		 
	
		 //$("div#user_feedback_form_container").show();
		// $("div#div_user_feedback_form").html('<iframe id="user_feedback_form" src="http://'+ hostname +'/wp-admin/admin-ajax.php?action=FeedbackForm&lang='+lang+'"  allowtransparency="true" frameborder="0" marginheight="0" marginheight="0" ></iframe>');
		 
        // $("div#div_user_feedback_form iframe#user_feedback_form").show();
    }); 
    
    $("div#close-button").click(function(e) {
    	closeWindow();
    });
    $("#closeform").click(function(e) {
        closeWindow();
    });
	//var $('div#sthoverbuttons');
	
	/*$(window).resize(function(e) {
		var share_top = $('a#user_feedback_form').css('top').replace('.px','');
		//var feedback_top = parseInt(share_top) + 150;
		//$('a#user_feedback_form').css({'top': feedback_top + 'px'});
		
    });*/   
    ///////////////////////////////////////////////////////////////////
    
    
});